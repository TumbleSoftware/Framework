<?php
 //ini_set('display_errors', FALSE);
  require('../../framework.php');
  include('./inc_common.php');
  
  
  $template->load_single_template(); 
  
  
  $template->display_html('CMS - Welcome');
?>